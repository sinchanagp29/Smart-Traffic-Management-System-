require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASS || '',
  database: process.env.DB_NAME || 'smart_traffic',
  waitForConnections: true,
  connectionLimit: 10,
});

app.get('/entries', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM entries ORDER BY created_at DESC');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/entries', async (req, res) => {
  try {
    const { sensor_id, user_id, type, payload } = req.body;
    const [result] = await pool.query(
      'INSERT INTO entries (sensor_id, user_id, type, payload) VALUES (?, ?, ?, ?)',
      [sensor_id, user_id, type, JSON.stringify(payload || {})]
    );
    res.json({ id: result.insertId, sensor_id, user_id, type, payload });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`✅ Backend running on http://localhost:${PORT}`));
