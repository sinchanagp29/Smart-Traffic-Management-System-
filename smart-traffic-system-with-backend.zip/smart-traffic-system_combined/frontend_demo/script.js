const API_URL = "http://localhost:4000/entries";
const form = document.getElementById("entryForm");
const tableBody = document.querySelector("#entriesTable tbody");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const sensor_id = document.getElementById("sensorId").value;
  const user_id = document.getElementById("userId").value;
  const type = document.getElementById("type").value;
  const payloadInput = document.getElementById("payload").value;
  let payload = {};
  try { payload = JSON.parse(payloadInput); } catch { payload = { value: payloadInput }; }

  await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sensor_id, user_id, type, payload }),
  });
  form.reset();
  loadEntries();
});

async function loadEntries() {
  const res = await fetch(API_URL);
  const data = await res.json();
  tableBody.innerHTML = data.map(e => `
    <tr>
      <td>${e.id}</td>
      <td>${e.sensor_id}</td>
      <td>${e.user_id}</td>
      <td>${e.type}</td>
      <td>${JSON.stringify(e.payload)}</td>
      <td>${e.created_at ? new Date(e.created_at).toLocaleString() : ''}</td>
    </tr>
  `).join("");
}

window.onload = loadEntries;
