Smart Traffic System — Combined package
=====================================

This archive contains:
- frontend_original/   -> your original frontend (extracted from uploaded ZIP)
- frontend_demo/       -> a demo single-page frontend (HTML/CSS/JS) that interacts with backend
- backend/             -> Node.js + MySQL backend (ready-to-run)

Backend defaults:
- MySQL host: localhost
- MySQL user: root
- MySQL password: (empty)
- Database name: smart_traffic
- Server port: 4000

Quick setup (on your laptop)
----------------------------
1. Ensure MySQL is running locally.

2. Create the database and table:
   Open MySQL (e.g. `mysql -u root`) and run:
   ```
   CREATE DATABASE smart_traffic;
   USE smart_traffic;

   CREATE TABLE entries (
     id INT AUTO_INCREMENT PRIMARY KEY,
     sensor_id VARCHAR(100),
     user_id VARCHAR(100),
     type VARCHAR(50),
     payload JSON,
     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
   );
   ```

3. Start backend:
   ```
   cd backend
   npm install
   node server.js
   ```
   Server will run at: http://localhost:4000

4. Open frontend:
   - Open `frontend_demo/index.html` in Firefox (File -> Open File...) or drag into the browser.
   - Or open your original frontend at `frontend_original/` (open its index.html similarly).

Notes
-----
- `frontend_demo` is a simple example to test the API.
- If your original frontend expects different field names, edit its JS to point to the backend endpoint:
  e.g. replace API URL with: `http://localhost:4000/entries`
- For any issues, reply here and I will help you debug.

